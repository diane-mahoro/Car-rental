# __SAFETY CAR RENTALS__

## AUTHORS

- *Mugengano Alice*

- *Isimbi Ritha Jessica*

- *Umuhire Evelyne*

- *Mahoro Diane*

## Description

__SAFETY CAR RENTALS__ 
is web application made to help peaple explore different places of our country Rwanda by connecting them to different transport companies and service providers.

Not only the customers are the one to benefit but also the transport companies and sevice providers get the opportunity of adverstising their services hence an increase in the number of 
their customers.

## How the web works

- firstly the companies have to register
- secondary the users have to send their infos 
- thirdly we as the company we have to take the customers contact and connect them with the company they choosed
- after we will send them the message that we have arleady receive their reservation
- lastly we have to tell the company to go to their clients.

## Tools used

- *Google chrome browser*

- *Visual Studio Code*

- *Git and Github platform*

- *Database server*
- *html*
- *css*
- Javascript

## Active link

([SAFETY CAR RENTALS]())

### Linced under the terms of SAFETY CAR RENTALS


