$(document).ready(function(){
    $("#data").click(function(){
        alert("thank you for registering,we'll get back at you in a minute")
    })
})